#ifndef GAMEINFORMATION_H
#define GAMEINFORMATION_H

void GetInformation();
void GetasFile();
void savegame(int plturn);
int loadgame();

#endif