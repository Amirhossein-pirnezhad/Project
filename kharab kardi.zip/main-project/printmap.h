#ifndef PRINTMAP_H
#define PRINTMAP_H
#include "raylib.h"

void clrscr();
void DrawMap(int player);
Color checkColor(int player);

#endif //PRINTMAP_H
