#ifndef UPDATEGAME_H
#define UPDATEGAME_H

int canBuild(int gridX, int gridY, int player);
void conectionvillage(int gridX, int gridY, int player);
int update(int player);

#endif