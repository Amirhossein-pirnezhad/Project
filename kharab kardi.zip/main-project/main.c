#include <stdio.h>
#include <stdlib.h>
#include "printmap.h"
#include "generateMap.h"
#include "updategame.h"
#include "gameInformation.h"
#include "raylib.h"  

kingdom c[4];
Tile map[17][17];
int kingnum;
int alivePlayers;
int x, y;
double gameStartTime;
int minutes , seconds;
Texture2D background;
Sound lose;
Sound bubble;
Sound wrong;
Sound click;
Sound ding;
Sound badLuck;
Sound fight;

const int maxv=10;

int main() {
  int checkload = -1;
  clrscr();
  printf("chose:\n1 for scan Coordinates as file\n2 for Manually receiving coordinates\n3 for load game\n");
  int action;
  int sw = 1;
  while(sw){
    scanf("%d", &action); 
    switch (action){
      case 1:
        GetasFile();
        sw = 0;
        break;
      case 2:
        GetInformation();
        sw = 0;
        break;
      case 3:
        checkload = loadgame();
        sw = 0;
        break;
      default:
        printf("not found");
    }
  }
  gameStartTime = GetTime();

  InitAudioDevice();
  lose = LoadSound("sounds/kharabkardi.wav");
  Sound Win = LoadSound("sounds/Win.wav");
  bubble = LoadSound("sounds/bullb.wav");
  wrong = LoadSound("sounds/wrong.wav");
  click = LoadSound("sounds/click.mp3");
  ding = LoadSound("sounds/ding.wav");
  badLuck = LoadSound("sounds/badluck.mp3");
  fight = LoadSound("sounds/fight.mp3");

  InitWindow(GetMonitorWidth(0), GetMonitorHeight(0), "game");
  SetWindowSize(GetMonitorWidth(0), GetMonitorHeight(0)); 
  SetTargetFPS(60);

  background = LoadTexture("image/background.jpg");

  int player = 0;
  if (checkload != -1) {
    player = checkload;
    checkload = -1;
  }

  while (!WindowShouldClose()) {
    if(alivePlayers < 2) {
      int plwin;
      for(int i = 0; i < kingnum; i++) {
        if(c[i].isAlive) plwin = i;
      }
      Color color;
      color = checkColor(plwin);
      char info[20]; 
      double startTime = GetTime();
      
      PlaySound(Win); 
      while(GetTime() - startTime < 2) {
        BeginDrawing();
        ClearBackground(RAYWHITE);
        sprintf(info, "Player %d Win!", plwin+1);
        DrawText(info, 150, 150, 50, color);
        EndDrawing();
      }
      break;
    }

    for(; player < kingnum; player++) {
        if(c[player].isAlive) {
      
        int a = 0;
        BeginDrawing(); 
        ClearBackground(RAYWHITE);
        
        a = update(player);
        if(a) savegame(player);
        else player--;
        if(a==2){
          CloseWindow();
          break;
        }
        EndDrawing();
        }
    }
    player = 0;
  }

  CloseWindow();
  CloseAudioDevice();

  return 0;
} 