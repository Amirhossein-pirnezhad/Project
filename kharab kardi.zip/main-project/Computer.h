#ifndef COMPUTER_H
#define COMPUTER_H

int computer(int player);

#endif